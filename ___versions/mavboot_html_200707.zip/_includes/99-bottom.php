<?php
/********************************************************
MAVBOOT - UTA Themed Bootstrap Framework
99-bottom.php
DO NOT EDIT 
This page builds the main navigation. Only the site 
navigation menu at the bottom should be edited.
These scripts may not be needed for most sites, but 
many Bootstrap components require them.
See getbootstrap.com
*********************************************************/
?>
<!-- Optional JavaScript -->
<!-- jQuery first, then Bootstrap bundle JS -->
<script src="./_js/jquery-3.5.1.slim.min.js"></script>
<script src="./_js/bootstrap.bundle.min.js"></script>

</body>
</html>