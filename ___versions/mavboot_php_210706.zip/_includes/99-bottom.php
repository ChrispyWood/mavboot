<?php
/********************************************************
MAVBOOT - UTA Themed Bootstrap Framework
99-bottom.php
DO NOT EDIT 
See getbootstrap.com
*********************************************************/
?>

<!-- Bootstrap Bundle JS -->
<script src="./_js/bootstrap.bundle.min.js"></script>

</body>
</html>