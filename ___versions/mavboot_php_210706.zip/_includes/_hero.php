<div id="home-hero" style='background-image: url(_images/civil-engineers-concrete-beam.jpg)'>
    <div class='container'>
        <div class='hero-text'>
            <h1 class='display-1'>Lorem Ipsum Lab</h1>
            <p class='lead'>Suspendisse a odio vitae justo volutpat blandit a in est. Morbi tincidunt sodales semper. 
                Cras ut purus eu nibh scelerisque iaculis faucibus quis sem.</p>
        </div>
    </div>
</div>