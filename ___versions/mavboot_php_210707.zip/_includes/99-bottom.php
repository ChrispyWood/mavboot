<?php
/********************************************************
MAVBOOT - UTA Themed Bootstrap Framework
99-bottom.php
DO NOT EDIT 
See getbootstrap.com
*********************************************************/
?>

<!-- Bootstrap Bundle JS and Mavboot JS -->
<script src="./_js/bootstrap.bundle.min.js"></script>
<script src="./_js/mavboot.js"></script>
</body>
</html>