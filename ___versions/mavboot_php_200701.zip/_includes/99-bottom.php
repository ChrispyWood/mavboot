<!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="./_js/jquery-3.5.1.slim.min.js"></script>
<script src="./_js/bootstrap.bundle.min.js"></script>

</body>
</html>