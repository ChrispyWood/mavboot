<?php
/********************************************************
MAVBOOT - UTA Themed Bootstrap Framework
99-bottom.php
DO NOT EDIT 
See getbootstrap.com
*********************************************************/
?>

<!-- Bootstrap Bundle JS and Mavboot JS -->
<script src="<?php echo $subpage_depth;?>_js/bootstrap.bundle.min.js"></script>
<script src="<?php echo $subpage_depth;?>_js/mavboot.js"></script>

<!--

  _    _ _______         ______             _                      _             
 | |  | |__   __|/\     |  ____|           (_)                    (_)            
 | |  | |  | |  /  \    | |__   _ __   __ _ _ _ __   ___  ___ _ __ _ _ __   __ _ 
 | |  | |  | | / /\ \   |  __| | '_ \ / _` | | '_ \ / _ \/ _ \ '__| | '_ \ / _` |
 | |__| |  | |/ ____ \  | |____| | | | (_| | | | | |  __/  __/ |  | | | | | (_| |
  \____/   |_/_/    \_\ |______|_| |_|\__, |_|_| |_|\___|\___|_|  |_|_| |_|\__, |
                                       __/ |                                __/ |
                                      |___/                                |___/ 


-->

</body>
</html>